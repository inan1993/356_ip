README

ECE 356 - Network Architectures: IP Routing + Forwarding with RIP

Chris Dee
Inan Tainwala

Hours spent 			= 1,000,000 x billions hours
Lines of Code 			= 1,133



Instructions to run the routers:

First
Compile the assign2.c file using gcc with the pthread flag:
		gcc assign2.c -o assign2 -pthread

Second
Run it with the test files:
		./assign2 nodeA.c      etc.


